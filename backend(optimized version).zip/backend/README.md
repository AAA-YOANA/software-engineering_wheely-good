# WheelyGood Backend

Flask backend for the scooter rental coursework project. The service is MySQL-ready through SQLAlchemy and exposes REST APIs for the existing customer and admin React pages.

## Manual start

Open two terminals from the project root and run the backend and frontend separately.

### Backend

```powershell
cd c:\Users\33167\Desktop\Project\backend
$env:PORT="5001"
python app.py
```

If `python` is not on your PATH, use:

```powershell
cd c:\Users\33167\Desktop\Project\backend
$env:PORT="5001"
D:\Anaconda\python.exe app.py
```

### Frontend

```powershell
cd c:\Users\33167\Desktop\Project\用户界面\滑板车发现页-主页
$env:VITE_API_BASE_URL="http://127.0.0.1:5001"
npm exec vite -- --host 127.0.0.1 --port 5176 --strictPort
```

If `npm` is not on your PATH, use:

```powershell
cd c:\Users\33167\Desktop\Project\用户界面\滑板车发现页-主页
$env:VITE_API_BASE_URL="http://127.0.0.1:5001"
D:\NODE\npm.cmd exec vite -- --host 127.0.0.1 --port 5176 --strictPort
```

If the frontend reports missing dependencies the first time, run this once in the frontend directory:

```powershell
npm install
```

or:

```powershell
D:\NODE\npm.cmd install
```

### Local URLs

```text
Frontend: http://127.0.0.1:5176/
Backend health check: http://127.0.0.1:5001/api/health
```

## Setup

```powershell
cd backend
python -m pip install -r requirements.txt
```

## MySQL configuration

Create a MySQL database first:

```sql
CREATE DATABASE wheely_good CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Then run the app with a MySQL connection string:

```powershell
$env:DATABASE_URL="mysql+pymysql://root:password@127.0.0.1:3306/wheely_good"
python app.py
```

If `DATABASE_URL` is not set, the app uses `backend/wheely_good_dev.db` for local development.
The default port is `5000`; set `$env:PORT="5001"` before `python app.py` if that port is already in use.

## Demo accounts

The database is seeded automatically on first run.

```text
Admin:    admin@wheelygood.test / admin123
Customer: zhangwei@example.com / password123
Customer: lina@example.com / password123
```

## Main APIs

```text
POST /api/auth/register
POST /api/auth/login
GET  /api/users/me

GET  /api/scooters
GET  /api/scooters/:id
POST /api/bookings
GET  /api/bookings/me
POST /api/bookings/:id/cancel
POST /api/bookings/:id/end
POST /api/feedback
GET  /api/feedback/me

GET    /api/admin/users
GET    /api/admin/bookings
POST   /api/admin/bookings
POST   /api/admin/scooters
PATCH  /api/admin/scooters/:id
DELETE /api/admin/scooters/:id
PATCH  /api/admin/pricing
GET    /api/admin/feedback
PATCH  /api/admin/feedback/:id
GET    /api/admin/stats/rental-types
GET    /api/admin/stats/weekly-revenue
GET    /api/admin/stats/daily-revenue
```

Use the returned login token as:

```text
Authorization: Bearer <token>
```

## Tests

```powershell
cd backend
python -m pytest
```
