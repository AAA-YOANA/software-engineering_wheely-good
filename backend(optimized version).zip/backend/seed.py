from datetime import date, timedelta

from extensions import db
from models import Booking, Discount, Feedback, Payment, PricingTier, Scooter, User, utcnow


SCOOTER_IMAGE = (
    "https://images.unsplash.com/photo-1583322319396-08178ea4f8b3?"
    "crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
)


def seed_database():
    if User.query.first():
        return

    admin = User(name="Admin Manager", email="admin@wheelygood.test", phone="07000000000", role="admin")
    admin.set_password("admin123")
    users = [
        admin,
        User(name="Zhang Wei", email="zhangwei@example.com", phone="13800138001", user_group="frequent"),
        User(name="Li Na", email="lina@example.com", phone="13800138002", user_group="student"),
        User(name="Wang Qiang", email="wangqiang@example.com", phone="13800138003", user_group="all"),
    ]
    for user in users[1:]:
        user.set_password("password123")
    db.session.add_all(users)

    scooters = [
        Scooter(id="SC-001", name="Scooter Alpha", model="WheelyGood Pro", serial_number="WG-001", status="available", battery_level=85, latitude=39.9042, longitude=116.4074, address="City Centre Station A", image=SCOOTER_IMAGE, price_per_hour=25, last_maintenance=date(2026, 3, 25)),
        Scooter(id="SC-002", name="Scooter Beta", model="Ninebot Max G30", serial_number="WG-002", status="available", battery_level=25, latitude=39.9142, longitude=116.4174, address="City Centre Station B", image=SCOOTER_IMAGE, price_per_hour=25, last_maintenance=date(2026, 3, 20)),
        Scooter(id="SC-003", name="Scooter Gamma", model="Segway ES2", serial_number="WG-003", status="unavailable", battery_level=60, latitude=39.9092, longitude=116.4124, address="Library Square", image=SCOOTER_IMAGE, price_per_hour=25, last_maintenance=date(2026, 3, 28)),
        Scooter(id="SC-004", name="Scooter Delta", model="WheelyGood Lite", serial_number="WG-004", status="available", battery_level=95, latitude=39.9002, longitude=116.4024, address="North Gate", image=SCOOTER_IMAGE, price_per_hour=25, last_maintenance=date(2026, 3, 15)),
        Scooter(id="SC-005", name="Scooter Epsilon", model="WheelyGood Pro", serial_number="WG-005", status="maintenance", battery_level=72, latitude=39.9082, longitude=116.4154, address="Market Street", image=SCOOTER_IMAGE, price_per_hour=25, last_maintenance=date(2026, 3, 30)),
    ]
    db.session.add_all(scooters)

    db.session.add_all([
        PricingTier(duration="1hour", label="1 hour", hours=1, price=15, cost=3),
        PricingTier(duration="4hours", label="4 hours", hours=4, price=50, cost=10),
        PricingTier(duration="1day", label="1 day", hours=24, price=100, cost=20),
        PricingTier(duration="1week", label="1 week", hours=168, price=500, cost=100),
    ])

    db.session.add_all([
        Discount(name="Frequent user discount", user_group="frequent", type="percentage", value=15, min_rentals=10, active=True, description="Frequent users receive 15% off."),
        Discount(name="Student discount", user_group="student", type="percentage", value=20, active=True, description="Students receive 20% off."),
        Discount(name="Senior discount", user_group="senior", type="fixed", value=5, active=True, description="Senior users receive a fixed discount."),
    ])
    db.session.flush()

    now = utcnow().replace(minute=0, second=0, microsecond=0)
    bookings = [
        Booking(confirmation_code="WG0001", user_id=2, scooter_id="SC-003", rental_type="4hours", start_at=now - timedelta(days=3, hours=4), end_at=now - timedelta(days=3), base_cost=50, discount_amount=7.5, total_cost=42.5, status="completed"),
        Booking(confirmation_code="WG0002", user_id=3, scooter_id="SC-001", rental_type="1hour", start_at=now - timedelta(days=2, hours=1), end_at=now - timedelta(days=2), base_cost=15, discount_amount=3, total_cost=12, status="completed"),
        Booking(confirmation_code="WG0003", user_id=4, scooter_id="SC-004", rental_type="1day", start_at=now - timedelta(hours=1), end_at=now + timedelta(hours=23), base_cost=100, discount_amount=0, total_cost=100, status="active"),
        Booking(confirmation_code="WG0004", guest_name="Guest Rider", guest_phone="07123456789", guest_email="guest@example.com", scooter_id="SC-002", rental_type="1hour", start_at=now - timedelta(days=1, hours=1), end_at=now - timedelta(days=1), base_cost=15, discount_amount=0, total_cost=15, status="completed"),
    ]
    db.session.add_all(bookings)
    db.session.flush()
    db.session.add_all([
        Payment(booking_id=booking.id, amount=booking.total_cost, method="card", status="successful", card_last4="4242")
        for booking in bookings
    ])

    db.session.add_all([
        Feedback(user_id=2, user_name="Zhang Wei", user_email="zhangwei@example.com", title="Brake feels loose", description="The brake on scooter SC-001 felt loose during my ride.", category="scooter_fault", priority="high", status="in-progress", admin_reply="Thanks, we have moved this scooter to inspection."),
        Feedback(user_id=3, user_name="Li Na", user_email="lina@example.com", title="Payment question", description="I was not sure whether my student discount was applied.", category="payment", priority="low", status="pending"),
    ])

    db.session.commit()
