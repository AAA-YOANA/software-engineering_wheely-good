from datetime import datetime, timedelta, timezone
from werkzeug.security import check_password_hash, generate_password_hash

from extensions import db


def utcnow():
    return datetime.now(timezone.utc)


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    phone = db.Column(db.String(40), default="")
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="customer")
    status = db.Column(db.String(20), nullable=False, default="active")
    user_group = db.Column(db.String(20), nullable=False, default="all")
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow, nullable=False)

    bookings = db.relationship("Booking", back_populates="user", lazy=True)
    feedback_items = db.relationship("Feedback", back_populates="user", lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self, include_stats=False):
        data = {
            "id": str(self.id),
            "name": self.name,
            "email": self.email,
            "phone": self.phone,
            "role": self.role,
            "status": self.status,
            "userGroup": self.user_group,
            "registrationDate": self.created_at.date().isoformat(),
        }
        if include_stats:
            bookings = self.bookings
            data["totalBookings"] = len(bookings)
            data["totalSpent"] = float(sum(b.total_cost or 0 for b in bookings if b.status != "cancelled"))
            data["totalRentals"] = data["totalBookings"]
        return data


class Scooter(db.Model):
    __tablename__ = "scooters"

    id = db.Column(db.String(20), primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    model = db.Column(db.String(120), nullable=False)
    serial_number = db.Column(db.String(80), unique=True, nullable=False)
    status = db.Column(db.String(30), nullable=False, default="available")
    battery_level = db.Column(db.Integer, nullable=False, default=100)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    address = db.Column(db.String(255), nullable=False)
    image = db.Column(db.Text, nullable=False)
    price_per_hour = db.Column(db.Numeric(10, 2), nullable=False, default=25)
    last_maintenance = db.Column(db.Date, nullable=True)

    bookings = db.relationship("Booking", back_populates="scooter", lazy=True)

    def frontend_status(self):
        if self.status in ("unavailable", "rented"):
            return "in-use"
        if self.status == "maintenance" or self.battery_level < 30:
            return "low-battery"
        return "available"

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "model": self.model,
            "serialNumber": self.serial_number,
            "status": self.frontend_status(),
            "adminStatus": self.status,
            "battery": self.battery_level,
            "batteryLevel": self.battery_level,
            "position": [self.latitude, self.longitude],
            "location": {
                "lat": self.latitude,
                "lng": self.longitude,
                "address": self.address,
            },
            "address": self.address,
            "image": self.image,
            "pricePerHour": float(self.price_per_hour),
            "lastMaintenance": self.last_maintenance.isoformat() if self.last_maintenance else None,
        }


class PricingTier(db.Model):
    __tablename__ = "pricing_tiers"

    duration = db.Column(db.String(20), primary_key=True)
    label = db.Column(db.String(80), nullable=False)
    hours = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    cost = db.Column(db.Numeric(10, 2), nullable=False, default=0)

    def to_dict(self):
        return {
            "duration": self.duration,
            "label": self.label,
            "hours": self.hours,
            "price": float(self.price),
            "cost": float(self.cost),
        }


class Discount(db.Model):
    __tablename__ = "discounts"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    user_group = db.Column(db.String(20), nullable=False, default="all")
    type = db.Column(db.String(20), nullable=False, default="percentage")
    value = db.Column(db.Numeric(10, 2), nullable=False, default=0)
    min_rentals = db.Column(db.Integer, nullable=True)
    active = db.Column(db.Boolean, nullable=False, default=True)
    description = db.Column(db.String(255), nullable=False, default="")

    def to_dict(self):
        return {
            "id": str(self.id),
            "name": self.name,
            "userGroup": self.user_group,
            "type": self.type,
            "value": float(self.value),
            "minRentals": self.min_rentals,
            "active": self.active,
            "description": self.description,
        }


class Booking(db.Model):
    __tablename__ = "bookings"

    id = db.Column(db.Integer, primary_key=True)
    confirmation_code = db.Column(db.String(20), unique=True, nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    guest_name = db.Column(db.String(120), default="")
    guest_phone = db.Column(db.String(40), default="")
    guest_email = db.Column(db.String(255), default="")
    scooter_id = db.Column(db.String(20), db.ForeignKey("scooters.id"), nullable=False)
    rental_type = db.Column(db.String(20), nullable=False)
    start_at = db.Column(db.DateTime(timezone=True), nullable=False)
    end_at = db.Column(db.DateTime(timezone=True), nullable=False)
    base_cost = db.Column(db.Numeric(10, 2), nullable=False)
    discount_amount = db.Column(db.Numeric(10, 2), nullable=False, default=0)
    total_cost = db.Column(db.Numeric(10, 2), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="active")
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow, nullable=False)

    user = db.relationship("User", back_populates="bookings")
    scooter = db.relationship("Scooter", back_populates="bookings")
    payment = db.relationship("Payment", back_populates="booking", uselist=False)

    def display_name(self):
        return self.user.name if self.user else self.guest_name

    def to_dict(self):
        return {
            "id": f"B{self.id:03d}",
            "confirmationCode": self.confirmation_code,
            "userId": str(self.user_id) if self.user_id else None,
            "userName": self.display_name(),
            "userPhone": self.user.phone if self.user else self.guest_phone,
            "userEmail": self.user.email if self.user else self.guest_email,
            "scooterId": self.scooter_id,
            "scooterModel": self.scooter.model if self.scooter else self.scooter_id,
            "rentalType": self.rental_type,
            "startDate": self.start_at.strftime("%Y-%m-%d %H:%M"),
            "endDate": self.end_at.strftime("%Y-%m-%d %H:%M"),
            "baseCost": float(self.base_cost),
            "discountAmount": float(self.discount_amount),
            "totalCost": float(self.total_cost),
            "price": float(self.total_cost),
            "status": self.status,
            "isRegistered": self.user_id is not None,
            "createdAt": self.created_at.isoformat(),
        }


class Payment(db.Model):
    __tablename__ = "payments"

    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey("bookings.id"), nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    method = db.Column(db.String(40), nullable=False, default="card")
    status = db.Column(db.String(20), nullable=False, default="successful")
    card_last4 = db.Column(db.String(4), default="")
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow, nullable=False)

    booking = db.relationship("Booking", back_populates="payment")

    def to_dict(self):
        return {
            "id": f"P{self.id:03d}",
            "bookingId": f"B{self.booking_id:03d}",
            "amount": float(self.amount),
            "method": self.method,
            "status": self.status,
            "cardLast4": self.card_last4,
            "createdAt": self.created_at.isoformat(),
        }


class Feedback(db.Model):
    __tablename__ = "feedback"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    user_name = db.Column(db.String(120), nullable=False)
    user_email = db.Column(db.String(255), nullable=False)
    title = db.Column(db.String(160), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(80), nullable=False)
    priority = db.Column(db.String(20), nullable=False, default="low")
    status = db.Column(db.String(20), nullable=False, default="pending")
    images = db.Column(db.Text, nullable=False, default="[]")
    admin_reply = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at = db.Column(db.DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)

    user = db.relationship("User", back_populates="feedback_items")

    def to_dict(self):
        import json

        status_for_customer = {
            "pending": "pending",
            "in-progress": "processing",
            "resolved": "resolved",
            "closed": "resolved",
        }.get(self.status, self.status)
        replies = []
        if self.admin_reply:
            replies.append({
                "id": f"R{self.id:03d}",
                "message": self.admin_reply,
                "isAdmin": True,
                "createdAt": self.updated_at.isoformat(),
            })
        return {
            "id": f"F{self.id:03d}",
            "title": self.title,
            "type": self.category,
            "typeLabel": self.category,
            "description": self.description,
            "images": json.loads(self.images or "[]"),
            "status": status_for_customer,
            "adminStatus": self.status,
            "priority": self.priority,
            "category": self.category,
            "userName": self.user_name,
            "userEmail": self.user_email,
            "createdAt": self.created_at.isoformat(),
            "updatedAt": self.updated_at.isoformat(),
            "adminReply": self.admin_reply,
            "replies": replies,
        }


def default_end_time(start_at, rental_type, hours=None):
    tier_hours = {
        "1hour": 1,
        "4hours": 4,
        "1day": 24,
        "1week": 24 * 7,
    }
    return start_at + timedelta(hours=hours or tier_hours.get(rental_type, 1))
