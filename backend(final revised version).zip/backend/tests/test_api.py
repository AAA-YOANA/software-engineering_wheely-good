import pytest

from app import create_app
from config import TestConfig
from extensions import db
from seed import seed_database


@pytest.fixture()
def client():
    app = create_app(TestConfig)
    with app.app_context():
        db.create_all()
        seed_database()
    return app.test_client()


def login(client, email="zhangwei@example.com", password="password123"):
    response = client.post("/api/auth/login", json={"email": email, "password": password})
    assert response.status_code == 200
    return response.get_json()["token"]


def admin_login(client):
    return login(client, "admin@wheelygood.test", "admin123")


def test_login_and_current_user(client):
    token = login(client)
    response = client.get("/api/users/me", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    assert response.get_json()["email"] == "zhangwei@example.com"


def test_scooter_list_is_public(client):
    response = client.get("/api/scooters")
    assert response.status_code == 200
    scooters = response.get_json()
    assert len(scooters) >= 5
    assert {"id", "position", "battery", "status", "image"}.issubset(scooters[0])


def test_customer_can_create_booking_and_scooter_becomes_unavailable(client):
    token = login(client)
    response = client.post(
        "/api/bookings",
        headers={"Authorization": f"Bearer {token}"},
        json={"scooterId": "SC-001", "rentalType": "1hour", "cardNumber": "4242424242424242"},
    )
    assert response.status_code == 201
    body = response.get_json()
    assert body["booking"]["scooterId"] == "SC-001"
    assert body["payment"]["status"] == "successful"

    scooters = client.get("/api/scooters").get_json()
    scooter = next(item for item in scooters if item["id"] == "SC-001")
    assert scooter["status"] == "in-use"


def test_admin_stats_require_admin(client):
    user_token = login(client)
    response = client.get("/api/admin/stats/rental-types", headers={"Authorization": f"Bearer {user_token}"})
    assert response.status_code == 403

    admin_token = admin_login(client)
    response = client.get("/api/admin/stats/rental-types", headers={"Authorization": f"Bearer {admin_token}"})
    assert response.status_code == 200
    assert "1hour" in response.get_json()


def test_feedback_flow(client):
    token = login(client)
    response = client.post(
        "/api/feedback",
        headers={"Authorization": f"Bearer {token}"},
        json={"type": "scooter_fault", "typeLabel": "Scooter fault", "description": "Brake issue"},
    )
    assert response.status_code == 201
    assert response.get_json()["status"] == "pending"
