import os
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-before-submission")
    JWT_SECRET = os.getenv("JWT_SECRET", SECRET_KEY)
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JSON_SORT_KEYS = False

    # Use MySQL by setting DATABASE_URL, for example:
    # mysql+pymysql://root:password@127.0.0.1:3306/wheely_good
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URL",
        f"sqlite:///{BASE_DIR / 'wheely_good_dev.db'}",
    )


class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
