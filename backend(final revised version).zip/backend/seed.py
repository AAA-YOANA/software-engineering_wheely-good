from datetime import date, timedelta

from extensions import db
from models import Booking, Discount, Feedback, Payment, PricingTier, Scooter, User, utcnow


SCOOTER_IMAGES = [
    "https://images.unsplash.com/photo-1583322319396-08178ea4f8b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    "https://images.unsplash.com/photo-1629099580192-b8300533fc06?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    "https://images.unsplash.com/photo-1742078684146-43ad5c9a7388?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    "https://images.unsplash.com/photo-1623079400394-f07956928c3f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
]


def seed_database():
    now = utcnow().replace(minute=0, second=0, microsecond=0)

    users = [
        {"name": "Admin Manager", "email": "admin@wheelygood.test", "phone": "07000000000", "role": "admin", "password": "admin123", "user_group": "all"},
        {"name": "Zhang Wei", "email": "zhangwei@example.com", "phone": "13800138001", "role": "customer", "password": "password123", "user_group": "frequent"},
        {"name": "Li Na", "email": "lina@example.com", "phone": "13800138002", "role": "customer", "password": "password123", "user_group": "student"},
        {"name": "Wang Qiang", "email": "wangqiang@example.com", "phone": "13800138003", "role": "customer", "password": "password123", "user_group": "all"},
    ]
    for item in users:
        user = User.query.filter_by(email=item["email"]).first()
        if not user:
            user = User(
                name=item["name"],
                email=item["email"],
                phone=item["phone"],
                role=item["role"],
                user_group=item["user_group"],
            )
            user.set_password(item["password"])
            db.session.add(user)
    db.session.flush()

    scooters = [
        {"id": "SC-001", "name": "Scooter Alpha", "model": "WheelyGood Pro", "serial_number": "WG-001", "status": "available", "battery_level": 85, "latitude": 30.5728, "longitude": 104.0668, "address": "Tianfu Square", "image": SCOOTER_IMAGES[0], "price_per_hour": 25, "last_maintenance": date(2026, 3, 25)},
        {"id": "SC-002", "name": "Scooter Beta", "model": "Ninebot Max G30", "serial_number": "WG-002", "status": "available", "battery_level": 25, "latitude": 30.6586, "longitude": 104.0647, "address": "Chunxi Road", "image": SCOOTER_IMAGES[2], "price_per_hour": 25, "last_maintenance": date(2026, 3, 20)},
        {"id": "SC-003", "name": "Scooter Gamma", "model": "Segway ES2", "serial_number": "WG-003", "status": "unavailable", "battery_level": 60, "latitude": 30.5723, "longitude": 104.0862, "address": "Taikoo Li", "image": SCOOTER_IMAGES[1], "price_per_hour": 25, "last_maintenance": date(2026, 3, 28)},
        {"id": "SC-004", "name": "Scooter Delta", "model": "WheelyGood Lite", "serial_number": "WG-004", "status": "available", "battery_level": 95, "latitude": 30.6307, "longitude": 104.0685, "address": "Wenshu Monastery", "image": SCOOTER_IMAGES[3], "price_per_hour": 25, "last_maintenance": date(2026, 3, 15)},
        {"id": "SC-005", "name": "Scooter Epsilon", "model": "WheelyGood Pro", "serial_number": "WG-005", "status": "maintenance", "battery_level": 72, "latitude": 30.6040, "longitude": 104.0741, "address": "Jiuyan Bridge", "image": SCOOTER_IMAGES[0], "price_per_hour": 25, "last_maintenance": date(2026, 3, 30)},
    ]
    for item in scooters:
        scooter = db.session.get(Scooter, item["id"])
        if not scooter:
            db.session.add(Scooter(**item))
        else:
            scooter.name = item["name"]
            scooter.model = item["model"]
            scooter.serial_number = item["serial_number"]
            scooter.status = item["status"]
            scooter.battery_level = item["battery_level"]
            scooter.latitude = item["latitude"]
            scooter.longitude = item["longitude"]
            scooter.address = item["address"]
            scooter.image = item["image"]
            scooter.price_per_hour = item["price_per_hour"]
            scooter.last_maintenance = item["last_maintenance"]

    pricing_tiers = [
        {"duration": "1hour", "label": "1 hour", "hours": 1, "price": 15, "cost": 3},
        {"duration": "4hours", "label": "4 hours", "hours": 4, "price": 50, "cost": 10},
        {"duration": "1day", "label": "1 day", "hours": 24, "price": 100, "cost": 20},
        {"duration": "1week", "label": "1 week", "hours": 168, "price": 500, "cost": 100},
    ]
    for item in pricing_tiers:
        tier = db.session.get(PricingTier, item["duration"])
        if not tier:
            db.session.add(PricingTier(**item))

    discounts = [
        {"name": "Frequent user discount", "user_group": "frequent", "type": "percentage", "value": 15, "min_rentals": 0, "active": True, "description": "Frequent users receive 15% off after 8+ hours in a week."},
        {"name": "Student discount", "user_group": "student", "type": "percentage", "value": 20, "min_rentals": 0, "active": True, "description": "Students receive 20% off."},
        {"name": "Senior discount", "user_group": "senior", "type": "fixed", "value": 5, "min_rentals": 0, "active": True, "description": "Senior users receive a fixed discount."},
    ]
    for item in discounts:
        existing = Discount.query.filter_by(name=item["name"]).first()
        if not existing:
            db.session.add(Discount(**item))
    db.session.flush()

    user_lookup = {user.email: user for user in User.query.all()}
    bookings = [
        {"confirmation_code": "WG0001", "user_email": "zhangwei@example.com", "scooter_id": "SC-003", "rental_type": "4hours", "start_at": now - timedelta(days=3, hours=4), "end_at": now - timedelta(days=3), "base_cost": 50, "discount_amount": 7.5, "total_cost": 42.5, "status": "completed"},
        {"confirmation_code": "WG0002", "user_email": "lina@example.com", "scooter_id": "SC-001", "rental_type": "1hour", "start_at": now - timedelta(days=2, hours=1), "end_at": now - timedelta(days=2), "base_cost": 15, "discount_amount": 3, "total_cost": 12, "status": "completed"},
        {"confirmation_code": "WG0003", "user_email": "wangqiang@example.com", "scooter_id": "SC-004", "rental_type": "1day", "start_at": now - timedelta(hours=1), "end_at": now + timedelta(hours=23), "base_cost": 100, "discount_amount": 0, "total_cost": 100, "status": "active"},
        {"confirmation_code": "WG0004", "guest_name": "Guest Rider", "guest_phone": "07123456789", "guest_email": "guest@example.com", "scooter_id": "SC-002", "rental_type": "1hour", "start_at": now - timedelta(days=1, hours=1), "end_at": now - timedelta(days=1), "base_cost": 15, "discount_amount": 0, "total_cost": 15, "status": "completed"},
    ]
    for item in bookings:
        existing = Booking.query.filter_by(confirmation_code=item["confirmation_code"]).first()
        if existing:
            continue
        user_email = item.pop("user_email", None)
        if user_email:
            user = user_lookup.get(user_email)
            item["user_id"] = user.id if user else None
        booking = Booking(**item)
        db.session.add(booking)
        db.session.flush()
        if not Payment.query.filter_by(booking_id=booking.id).first():
            db.session.add(Payment(booking_id=booking.id, amount=booking.total_cost, method="card", status="successful", card_last4="4242"))

    feedback_items = [
        {"user_email": "zhangwei@example.com", "title": "Brake feels loose", "description": "The brake on scooter SC-001 felt loose during my ride.", "category": "scooter_fault", "priority": "high", "status": "in-progress", "admin_reply": "Thanks, we have moved this scooter to inspection."},
        {"user_email": "lina@example.com", "title": "Payment question", "description": "I was not sure whether my student discount was applied.", "category": "payment", "priority": "low", "status": "pending", "admin_reply": ""},
    ]
    for item in feedback_items:
        existing = Feedback.query.filter_by(title=item["title"]).first()
        if existing:
            continue
        user = user_lookup.get(item["user_email"])
        db.session.add(
            Feedback(
                user_id=user.id if user else None,
                user_name=user.name if user else "Guest User",
                user_email=item["user_email"],
                title=item["title"],
                description=item["description"],
                category=item["category"],
                priority=item["priority"],
                status=item["status"],
                admin_reply=item["admin_reply"],
            )
        )

    db.session.commit()
