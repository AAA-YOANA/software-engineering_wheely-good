# WheelyGood Backend

Flask backend for the scooter rental coursework project. The service is MySQL-ready through SQLAlchemy and exposes REST APIs for the customer and admin React pages.

## Start The Website Again

If you close the terminals, open two new PowerShell windows and run these commands.

### Backend

This version is the most stable because it turns off the Flask auto-reloader.

```powershell
cd c:\Users\33167\Desktop\Project\backend
D:\Anaconda\python.exe -c "from app import app; app.run(host='127.0.0.1', port=5001, debug=False, use_reloader=False)"
```

If `D:\Anaconda\python.exe` is not correct on your machine, use:

```powershell
cd c:\Users\33167\Desktop\Project\backend
python -c "from app import app; app.run(host='127.0.0.1', port=5001, debug=False, use_reloader=False)"
```

Keep this terminal window open while using the site.

### Frontend

Open a second PowerShell window:

```powershell
cd "c:\Users\33167\Desktop\Project\用户界面\滑板车发现页-主页"
$env:VITE_API_BASE_URL="http://127.0.0.1:5001"
D:\NODE\npm.cmd exec vite -- --host 127.0.0.1 --port 5176 --strictPort
```

If `D:\NODE\npm.cmd` is not correct on your machine, use:

```powershell
cd "c:\Users\33167\Desktop\Project\用户界面\滑板车发现页-主页"
$env:VITE_API_BASE_URL="http://127.0.0.1:5001"
npm exec vite -- --host 127.0.0.1 --port 5176 --strictPort
```

Keep this terminal window open as well.

### First-Time Frontend Install

If the frontend reports missing dependencies, run this once in the frontend directory:

```powershell
cd "c:\Users\33167\Desktop\Project\用户界面\滑板车发现页-主页"
D:\NODE\npm.cmd install
```

or:

```powershell
cd "c:\Users\33167\Desktop\Project\用户界面\滑板车发现页-主页"
npm install
```

### Local URLs

```text
Frontend: http://127.0.0.1:5176/
Backend health check: http://127.0.0.1:5001/api/health
```

## Setup

```powershell
cd c:\Users\33167\Desktop\Project\backend
D:\Anaconda\python.exe -m pip install -r requirements.txt
```

or:

```powershell
cd c:\Users\33167\Desktop\Project\backend
python -m pip install -r requirements.txt
```

## MySQL Configuration

Create a MySQL database first:

```sql
CREATE DATABASE wheely_good CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Then run the app with a MySQL connection string:

```powershell
cd c:\Users\33167\Desktop\Project\backend
$env:DATABASE_URL="mysql+pymysql://root:password@127.0.0.1:3306/wheely_good"
D:\Anaconda\python.exe -c "from app import app; app.run(host='127.0.0.1', port=5001, debug=False, use_reloader=False)"
```

If `DATABASE_URL` is not set, the app uses `backend/wheely_good_dev.db` for local development.

## Demo Accounts

The database is seeded automatically on first run.

```text
Admin:    admin@wheelygood.test / admin123
Customer: zhangwei@example.com / password123
Customer: lina@example.com / password123
```

## Main APIs

```text
POST /api/auth/register
POST /api/auth/login
GET  /api/users/me

GET  /api/scooters
GET  /api/scooters/:id
POST /api/bookings
GET  /api/bookings/me
POST /api/bookings/:id/cancel
POST /api/bookings/:id/end
POST /api/feedback
GET  /api/feedback/me

GET    /api/admin/users
GET    /api/admin/bookings
POST   /api/admin/bookings
POST   /api/admin/scooters
PATCH  /api/admin/scooters/:id
DELETE /api/admin/scooters/:id
PATCH  /api/admin/pricing
GET    /api/admin/feedback
PATCH  /api/admin/feedback/:id
GET    /api/admin/stats/rental-types
GET    /api/admin/stats/weekly-revenue
GET    /api/admin/stats/daily-revenue
```

Use the returned login token as:

```text
Authorization: Bearer <token>
```

## Tests

```powershell
cd c:\Users\33167\Desktop\Project\backend
D:\Anaconda\python.exe -m pytest
```

or:

```powershell
cd c:\Users\33167\Desktop\Project\backend
python -m pytest
```
