from datetime import datetime, timedelta, timezone
from functools import wraps
import json
import os
import random
import string

import jwt
from flask import Flask, jsonify, request
from flask_cors import CORS
from sqlalchemy import func

from config import Config
from extensions import db
from models import Booking, Discount, Feedback, Payment, PricingTier, Scooter, User, default_end_time, ensure_aware, utcnow
from seed import seed_database


def create_app(config_object=Config):
    app = Flask(__name__)
    app.config.from_object(config_object)
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    db.init_app(app)

    with app.app_context():
        db.create_all()
        if not app.config.get("TESTING"):
            seed_database()

    register_routes(app)
    return app


def generate_token(user):
    payload = {
        "sub": str(user.id),
        "role": user.role,
        "exp": datetime.now(timezone.utc) + timedelta(hours=12),
    }
    return jwt.encode(payload, current_app_config()["JWT_SECRET"], algorithm="HS256")


def current_app_config():
    from flask import current_app

    return current_app.config


def get_current_user(optional=False):
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        if optional:
            return None
        return None
    token = header.removeprefix("Bearer ").strip()
    try:
        payload = jwt.decode(token, current_app_config()["JWT_SECRET"], algorithms=["HS256"])
        return db.session.get(User, int(payload["sub"]))
    except Exception:
        return None


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if not user:
            return error("Authentication required", 401)
        return fn(user, *args, **kwargs)

    return wrapper


def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if not user:
            return error("Authentication required", 401)
        if user.role != "admin":
            return error("Admin permission required", 403)
        return fn(user, *args, **kwargs)

    return wrapper


def error(message, status=400):
    return jsonify({"error": message}), status


def parse_dt(value):
    if not value:
        return utcnow()
    if isinstance(value, str):
        clean = value.replace("Z", "+00:00")
        return datetime.fromisoformat(clean)
    return value


def confirmation_code():
    while True:
        code = "WG" + "".join(random.choices(string.digits, k=6))
        if not Booking.query.filter_by(confirmation_code=code).first():
            return code


def calculate_discount(user, base_cost):
    if not user:
        return 0
    week_ago = utcnow() - timedelta(days=7)
    recent_completed = Booking.query.filter(
        Booking.user_id == user.id,
        Booking.status == "completed",
        Booking.end_at >= week_ago,
    ).all()
    recent_hours = 0
    for booking in recent_completed:
        hours = max(0, (booking.end_at - booking.start_at).total_seconds() / 3600)
        recent_hours += hours
    discounts = Discount.query.filter_by(active=True).all()
    best = 0
    for discount in discounts:
        if discount.user_group not in ("all", user.user_group):
            continue
        if discount.user_group == "frequent" and recent_hours < 8:
            continue
        if discount.user_group != "frequent" and discount.min_rentals and len(recent_completed) < discount.min_rentals:
            continue
        amount = float(base_cost) * float(discount.value) / 100 if discount.type == "percentage" else float(discount.value)
        best = max(best, amount)
    return round(min(best, float(base_cost)), 2)


def normalize_card_number(value):
    return "".join(ch for ch in str(value or "") if ch.isdigit())


def validate_card_details(data):
    payment_method = data.get("paymentMethod", "card")
    if payment_method != "card":
        return payment_method, ""
    card_number = normalize_card_number(data.get("cardNumber"))
    if len(card_number) < 12:
        raise ValueError("A valid simulated card number is required")
    return payment_method, card_number


def compute_live_charge(booking, end_at=None):
    end_time = ensure_aware(end_at or utcnow())
    start_at = ensure_aware(booking.start_at)
    elapsed_seconds = max(60, (end_time - start_at).total_seconds())
    elapsed_hours = elapsed_seconds / 3600
    rate_per_hour = float(booking.scooter.price_per_hour if booking.scooter else 25)
    base_cost = round(elapsed_hours * rate_per_hour, 2)
    discount_amount = calculate_discount(booking.user, base_cost)
    total_cost = round(base_cost - discount_amount, 2)
    return base_cost, discount_amount, total_cost


def register_routes(app):
    @app.get("/api/health")
    def health():
        return {"status": "ok", "service": "wheely-good-backend"}

    @app.post("/api/auth/register")
    def register():
        data = request.get_json() or {}
        name = data.get("name", "").strip()
        email = data.get("email", "").strip().lower()
        password = data.get("password", "")
        if not name or not email or len(password) < 6:
            return error("Name, email and a password of at least 6 characters are required")
        if User.query.filter_by(email=email).first():
            return error("Email is already registered", 409)
        user = User(name=name, email=email, phone=data.get("phone", ""), role=data.get("role", "customer"))
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        return jsonify({"token": generate_token(user), "user": user.to_dict(include_stats=True)}), 201

    @app.post("/api/auth/login")
    def login():
        data = request.get_json() or {}
        email = data.get("email", "").strip().lower()
        password = data.get("password", "")
        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password):
            return error("Invalid email or password", 401)
        return {"token": generate_token(user), "user": user.to_dict(include_stats=True)}

    @app.get("/api/users/me")
    @login_required
    def me(user):
        return user.to_dict(include_stats=True)

    @app.get("/api/admin/users")
    @admin_required
    def admin_users(_admin):
        return jsonify([u.to_dict(include_stats=True) for u in User.query.order_by(User.created_at.desc()).all()])

    @app.get("/api/admin/users/<int:user_id>")
    @admin_required
    def admin_user_detail(_admin, user_id):
        user = db.session.get(User, user_id)
        if not user:
            return error("User not found", 404)
        return {**user.to_dict(include_stats=True), "bookings": [b.to_dict() for b in user.bookings]}

    @app.get("/api/scooters")
    def scooters():
        status = request.args.get("status")
        query = Scooter.query
        if status and status != "all":
            if status == "in-use":
                query = query.filter(Scooter.status.in_(["unavailable", "rented"]))
            elif status == "low-battery":
                query = query.filter((Scooter.battery_level < 30) | (Scooter.status == "maintenance"))
            else:
                query = query.filter_by(status=status)
        return jsonify([s.to_dict() for s in query.order_by(Scooter.id).all()])

    @app.get("/api/scooters/<scooter_id>")
    def scooter_detail(scooter_id):
        scooter = db.session.get(Scooter, scooter_id)
        if not scooter:
            return error("Scooter not found", 404)
        return scooter.to_dict()

    @app.post("/api/admin/scooters")
    @admin_required
    def create_scooter(_admin):
        data = request.get_json() or {}
        scooter = Scooter(
            id=data["id"],
            name=data.get("name") or data.get("model") or data["id"],
            model=data.get("model", "WheelyGood Scooter"),
            serial_number=data.get("serialNumber", data["id"]),
            status=data.get("adminStatus") or data.get("status", "available"),
            battery_level=int(data.get("batteryLevel", data.get("battery", 100))),
            latitude=float(data.get("lat", data.get("latitude", 0))),
            longitude=float(data.get("lng", data.get("longitude", 0))),
            address=data.get("address", data.get("location", "City Centre")),
            image=data.get("image", ""),
            price_per_hour=float(data.get("pricePerHour", 25)),
        )
        db.session.add(scooter)
        db.session.commit()
        return scooter.to_dict(), 201

    @app.patch("/api/admin/scooters/<scooter_id>")
    @admin_required
    def update_scooter(_admin, scooter_id):
        scooter = db.session.get(Scooter, scooter_id)
        if not scooter:
            return error("Scooter not found", 404)
        data = request.get_json() or {}
        requested_status = data.get("adminStatus", data.get("status"))
        battery_provided = "batteryLevel" in data or "battery" in data
        mapping = {
            "name": "name",
            "model": "model",
            "serialNumber": "serial_number",
            "adminStatus": "status",
            "status": "status",
            "batteryLevel": "battery_level",
            "battery": "battery_level",
            "address": "address",
            "image": "image",
            "pricePerHour": "price_per_hour",
        }
        for key, attr in mapping.items():
            if key in data:
                setattr(scooter, attr, data[key])
        if requested_status == "available" and not battery_provided and scooter.battery_level < 30:
            scooter.battery_level = 100
        if requested_status == "available" and scooter.battery_level >= 30:
            scooter.status = "available"
        if "location" in data and isinstance(data["location"], dict):
            scooter.latitude = data["location"].get("lat", scooter.latitude)
            scooter.longitude = data["location"].get("lng", scooter.longitude)
            scooter.address = data["location"].get("address", scooter.address)
        db.session.commit()
        return scooter.to_dict()

    @app.delete("/api/admin/scooters/<scooter_id>")
    @admin_required
    def delete_scooter(_admin, scooter_id):
        scooter = db.session.get(Scooter, scooter_id)
        if not scooter:
            return error("Scooter not found", 404)
        db.session.delete(scooter)
        db.session.commit()
        return {"deleted": scooter_id}

    @app.get("/api/pricing")
    def pricing():
        return jsonify([p.to_dict() for p in PricingTier.query.order_by(PricingTier.hours).all()])

    @app.patch("/api/admin/pricing")
    @admin_required
    def update_pricing(_admin):
        data = request.get_json() or []
        for item in data:
            tier = db.session.get(PricingTier, item.get("duration"))
            if tier:
                tier.price = item.get("price", tier.price)
                tier.cost = item.get("cost", tier.cost)
                tier.label = item.get("label", tier.label)
        db.session.commit()
        return jsonify([p.to_dict() for p in PricingTier.query.order_by(PricingTier.hours).all()])

    @app.get("/api/admin/discounts")
    @admin_required
    def discounts(_admin):
        return jsonify([d.to_dict() for d in Discount.query.all()])

    @app.patch("/api/admin/discounts")
    @admin_required
    def update_discounts(_admin):
        data = request.get_json() or []
        updated = []
        for item in data:
            discount = db.session.get(Discount, int(item.get("id", 0)))
            if not discount:
                continue
            if "name" in item:
                discount.name = item["name"]
            if "userGroup" in item:
                discount.user_group = item["userGroup"]
            if "type" in item:
                discount.type = item["type"]
            if "value" in item:
                discount.value = item["value"]
            if "minRentals" in item:
                discount.min_rentals = item["minRentals"]
            if "active" in item:
                discount.active = bool(item["active"])
            if "description" in item:
                discount.description = item["description"]
            updated.append(discount)
        db.session.commit()
        return jsonify([d.to_dict() for d in Discount.query.order_by(Discount.id).all()])

    @app.post("/api/bookings")
    @login_required
    def create_booking(user):
        return create_booking_from_payload(user)

    @app.post("/api/admin/bookings")
    @admin_required
    def admin_create_booking(_admin):
        return create_booking_from_payload(None, guest=True)

    def create_booking_from_payload(user, guest=False):
        data = request.get_json() or {}
        scooter = db.session.get(Scooter, data.get("scooterId"))
        if not scooter:
            return error("Scooter not found", 404)
        active_conflict = Booking.query.filter_by(scooter_id=data.get("scooterId"), status="active").first()
        if active_conflict:
            return error("This scooter was just booked by another rider. Please refresh and choose another scooter.", 409)
        if scooter.status not in ("available",) or scooter.battery_level < 15:
            return error("Scooter is not available", 409)

        rental_type = data.get("rentalType") or data.get("duration", "1hour")
        tier = db.session.get(PricingTier, rental_type)
        if not tier:
            return error("Invalid rental type")
        start_at = parse_dt(data.get("startAt") or data.get("startDate"))
        end_at = parse_dt(data.get("endAt") or data.get("endDate")) if data.get("endAt") or data.get("endDate") else default_end_time(start_at, rental_type, tier.hours if tier else None)
        if end_at <= start_at:
            return error("End time must be after start time")
        if guest:
            if not data.get("userName", "").strip():
                return error("Guest name is required")
            if not data.get("userPhone", "").strip():
                return error("Guest phone is required")
        try:
            payment_method, card_number = validate_card_details(data)
        except ValueError as exc:
            return error(str(exc))

        base_cost = 0
        discount_amount = 0
        total_cost = 0

        booking = Booking(
            confirmation_code=confirmation_code(),
            user_id=user.id if user else None,
            guest_name=data.get("userName", ""),
            guest_phone=data.get("userPhone", ""),
            guest_email=data.get("userEmail", ""),
            scooter_id=scooter.id,
            rental_type=rental_type,
            start_at=start_at,
            end_at=end_at,
            base_cost=base_cost,
            discount_amount=discount_amount,
            total_cost=total_cost,
            status="active",
        )
        scooter.status = "unavailable"
        db.session.add(booking)
        db.session.flush()
        payment = Payment(
            booking_id=booking.id,
            amount=0,
            method=payment_method,
            status="authorized",
            card_last4=card_number[-4:],
        )
        db.session.add(payment)
        db.session.commit()
        return jsonify({"booking": booking.to_dict(), "payment": payment.to_dict()}), 201

    @app.get("/api/bookings/me")
    @login_required
    def my_bookings(user):
        return jsonify([b.to_dict() for b in Booking.query.filter_by(user_id=user.id).order_by(Booking.created_at.desc()).all()])

    @app.get("/api/admin/bookings")
    @admin_required
    def admin_bookings(_admin):
        return jsonify([b.to_dict() for b in Booking.query.order_by(Booking.created_at.desc()).all()])

    @app.post("/api/bookings/<int:booking_id>/cancel")
    @login_required
    def cancel_booking(user, booking_id):
        booking = db.session.get(Booking, booking_id)
        if not booking or (booking.user_id != user.id and user.role != "admin"):
            return error("Booking not found", 404)
        booking.status = "cancelled"
        booking.scooter.status = "available"
        db.session.commit()
        return booking.to_dict()

    @app.post("/api/bookings/<int:booking_id>/end")
    @login_required
    def end_booking(user, booking_id):
        booking = db.session.get(Booking, booking_id)
        if not booking or (booking.user_id != user.id and user.role != "admin"):
            return error("Booking not found", 404)
        if booking.status != "active":
            return error("Only active rides can be ended", 409)
        actual_end = utcnow()
        base_cost, discount_amount, total_cost = compute_live_charge(booking, actual_end)
        booking.status = "completed"
        booking.end_at = actual_end
        booking.base_cost = base_cost
        booking.discount_amount = discount_amount
        booking.total_cost = total_cost
        booking.scooter.status = "available"
        if booking.payment:
            booking.payment.amount = total_cost
            booking.payment.status = "successful"
        db.session.commit()
        return booking.to_dict()

    @app.post("/api/bookings/<int:booking_id>/extend")
    @login_required
    def extend_booking(user, booking_id):
        booking = db.session.get(Booking, booking_id)
        if not booking or (booking.user_id != user.id and user.role != "admin"):
            return error("Booking not found", 404)
        if booking.status != "active":
            return error("Only active bookings can be extended", 409)
        data = request.get_json() or {}
        rental_type = data.get("rentalType", "1hour")
        tier = db.session.get(PricingTier, rental_type)
        if not tier:
            return error("Invalid extension type")
        try:
            payment_method, card_number = validate_card_details(data)
        except ValueError as exc:
            return error(str(exc))
        booking.end_at = default_end_time(booking.end_at, rental_type, tier.hours)
        db.session.commit()
        return jsonify({
            "booking": booking.to_dict(),
            "payment": {
                "bookingId": f"B{booking.id:03d}",
                "amount": float(booking.total_cost),
                "method": payment_method,
                "status": "authorized",
                "cardLast4": card_number[-4:],
            },
            "message": f"Reservation window extended by {tier.label}. Final billing still uses real ride time.",
        })

    @app.post("/api/payments")
    @login_required
    def create_payment(_user):
        data = request.get_json() or {}
        booking_id = int(str(data.get("bookingId", "")).removeprefix("B"))
        booking = db.session.get(Booking, booking_id)
        if not booking:
            return error("Booking not found", 404)
        try:
            payment_method, card_number = validate_card_details({"paymentMethod": data.get("method", "card"), "cardNumber": data.get("cardNumber", "")})
        except ValueError as exc:
            return error(str(exc))
        payment = Payment(booking_id=booking.id, amount=booking.total_cost, method=payment_method, status="successful", card_last4=card_number[-4:])
        db.session.add(payment)
        db.session.commit()
        return payment.to_dict(), 201

    @app.post("/api/bookings/<int:booking_id>/email-confirmation")
    @login_required
    def send_confirmation_email(user, booking_id):
        booking = db.session.get(Booking, booking_id)
        if not booking or (booking.user_id != user.id and user.role != "admin"):
            return error("Booking not found", 404)
        recipient = booking.user.email if booking.user else booking.guest_email
        if not recipient:
            return error("No email address is available for this booking")
        subject = f"WheelyGood booking confirmation {booking.confirmation_code}"
        preview = (
            f"Hello {booking.display_name()}, your booking for scooter {booking.scooter_id} "
            f"from {booking.start_at.strftime('%Y-%m-%d %H:%M')} to {booking.end_at.strftime('%Y-%m-%d %H:%M')} "
            f"has been confirmed. Total paid: {float(booking.total_cost):.2f}."
        )
        return jsonify({
            "recipient": recipient,
            "subject": subject,
            "preview": preview,
            "sentAt": utcnow().isoformat(),
            "status": "sent",
        })

    @app.post("/api/feedback")
    @login_required
    def create_feedback(user):
        data = request.get_json() or {}
        category = data.get("type") or data.get("category", "general")
        feedback = Feedback(
            user_id=user.id,
            user_name=user.name,
            user_email=user.email,
            title=data.get("title") or data.get("typeLabel") or category,
            description=data.get("description", ""),
            category=category,
            priority=data.get("priority", "low"),
            status="pending",
            images=json.dumps(data.get("images", [])),
        )
        db.session.add(feedback)
        db.session.commit()
        return feedback.to_dict(), 201

    @app.get("/api/feedback/me")
    @login_required
    def my_feedback(user):
        return jsonify([f.to_dict() for f in Feedback.query.filter_by(user_id=user.id).order_by(Feedback.created_at.desc()).all()])

    @app.get("/api/admin/feedback")
    @admin_required
    def admin_feedback(_admin):
        query = Feedback.query
        if request.args.get("priority"):
            query = query.filter_by(priority=request.args["priority"])
        return jsonify([f.to_dict() for f in query.order_by(Feedback.created_at.desc()).all()])

    @app.patch("/api/admin/feedback/<int:feedback_id>")
    @admin_required
    def update_feedback(_admin, feedback_id):
        feedback = db.session.get(Feedback, feedback_id)
        if not feedback:
            return error("Feedback not found", 404)
        data = request.get_json() or {}
        if "status" in data:
            feedback.status = data["status"]
        if "priority" in data:
            feedback.priority = data["priority"]
        if "adminReply" in data:
            feedback.admin_reply = data["adminReply"]
        feedback.updated_at = utcnow()
        db.session.commit()
        return feedback.to_dict()

    @app.get("/api/admin/stats/rental-types")
    @admin_required
    def rental_type_stats(_admin):
        rows = db.session.query(Booking.rental_type, func.count(Booking.id), func.sum(Booking.total_cost)).filter(Booking.status != "cancelled").group_by(Booking.rental_type).all()
        stats = {key: {"count": 0, "revenue": 0} for key in ["1hour", "4hours", "1day", "1week"]}
        for rental_type, count, revenue in rows:
            stats[rental_type] = {"count": count, "revenue": float(revenue or 0)}
        return stats

    @app.get("/api/admin/stats/weekly-revenue")
    @admin_required
    def weekly_revenue(_admin):
        bookings = Booking.query.filter(Booking.status != "cancelled").all()
        weeks = {}
        for booking in bookings:
            start = booking.start_at
            week_start = (start - timedelta(days=start.weekday())).date().isoformat()
            weeks.setdefault(week_start, {"week": week_start, "1hour": 0, "4hours": 0, "1day": 0, "1week": 0})
            weeks[week_start][booking.rental_type] += float(booking.total_cost)
        return jsonify(sorted(weeks.values(), key=lambda item: item["week"]))

    @app.get("/api/admin/stats/daily-revenue")
    @admin_required
    def daily_revenue(_admin):
        bookings = Booking.query.filter(Booking.status != "cancelled").all()
        days = {}
        for booking in bookings:
            day = booking.start_at.date().isoformat()
            days[day] = days.get(day, 0) + float(booking.total_cost)
        return jsonify([
            {"date": day, "revenue": revenue, "dayOfWeek": datetime.fromisoformat(day).strftime("%a")}
            for day, revenue in sorted(days.items())
        ])


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=True)
