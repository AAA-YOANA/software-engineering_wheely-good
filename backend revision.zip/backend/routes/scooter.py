from flask import Blueprint, jsonify, request

from models import Scooter

scooter_bp = Blueprint("scooter", __name__, url_prefix="/api/scooters")


@scooter_bp.get("")
def get_scooters():
    status = request.args.get("status", "all").strip()
    min_battery = request.args.get("min_battery", type=int, default=0)
    search = (request.args.get("search") or "").strip().lower()

    query = Scooter.query

    if status != "all":
        query = query.filter(Scooter.status == status)

    if min_battery > 0:
        query = query.filter(Scooter.battery >= min_battery)

    scooters = query.order_by(Scooter.scooter_code.asc()).all()

    results = []
    for scooter in scooters:
        data = scooter.to_dict()
        if search and search not in data["id"].lower():
            continue
        results.append(data)

    return jsonify({"success": True, "data": results})