from flask import Blueprint, jsonify, request

from models import Booking, User
from routes.auth import verify_token

user_bp = Blueprint("user", __name__, url_prefix="/api/user")


def get_current_user():
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return None

    token = auth_header.split(" ", 1)[1].strip()
    data = verify_token(token)
    if not data:
        return None

    return User.query.get(data["user_id"])


@user_bp.get("/profile")
def profile():
    user = get_current_user()
    if not user:
        return jsonify({"success": False, "message": "Unauthorized"}), 401

    return jsonify({"success": True, "data": user.to_dict()})


@user_bp.get("/stats")
def stats():
    user = get_current_user()
    if not user:
        return jsonify({"success": False, "message": "Unauthorized"}), 401

    bookings = Booking.query.filter_by(user_id=user.id).all()

    total_distance = sum((b.distance or 0) for b in bookings)
    total_orders = len(bookings)

    return jsonify(
        {
            "success": True,
            "data": {
                "total_distance": round(total_distance, 1),
                "total_orders": total_orders,
            },
        }
    )