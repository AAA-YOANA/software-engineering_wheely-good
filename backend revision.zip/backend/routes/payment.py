from flask import Blueprint, jsonify, request

from models import Payment, User
from routes.auth import verify_token

payment_bp = Blueprint("payment", __name__, url_prefix="/api/payment")


def get_user():
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return None

    token = auth_header.split(" ", 1)[1].strip()
    data = verify_token(token)
    if not data:
        return None

    return User.query.get(data["user_id"])


@payment_bp.get("")
def get_cards():
    user = get_user()
    if not user:
        return jsonify({"success": False, "message": "Unauthorized"}), 401

    cards = Payment.query.filter_by(user_id=user.id).all()

    return jsonify(
        {
            "success": True,
            "data": [card.to_dict() for card in cards],
        }
    )