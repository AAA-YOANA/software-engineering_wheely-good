from datetime import datetime

from flask import Blueprint, jsonify, request

from extensions import db
from models import Booking, Scooter, User
from routes.auth import verify_token

booking_bp = Blueprint("booking", __name__, url_prefix="/api/bookings")


def get_current_user_from_token():
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return None

    token = auth_header.split(" ", 1)[1].strip()
    payload = verify_token(token)
    if not payload:
        return None

    return User.query.get(payload["user_id"])


@booking_bp.get("/my")
def get_my_bookings():
    user = get_current_user_from_token()
    if not user:
        return jsonify({"success": False, "message": "Unauthorized"}), 401

    bookings = (
        Booking.query.filter_by(user_id=user.id)
        .order_by(Booking.start_time.desc())
        .all()
    )

    return jsonify(
        {
            "success": True,
            "data": [booking.to_dict() for booking in bookings],
        }
    )


@booking_bp.post("/start")
def start_booking():
    user = get_current_user_from_token()
    if not user:
        return jsonify({"success": False, "message": "Unauthorized"}), 401

    existing_ongoing = Booking.query.filter_by(user_id=user.id, status="ongoing").first()
    if existing_ongoing:
        return (
            jsonify(
                {
                    "success": False,
                    "message": "You already have an ongoing trip.",
                }
            ),
            409,
        )

    data = request.get_json(silent=True) or {}
    scooter_code = (data.get("scooter_id") or "").strip()

    if not scooter_code:
        return jsonify({"success": False, "message": "scooter_id is required."}), 400

    scooter = Scooter.query.filter_by(scooter_code=scooter_code).first()
    if not scooter:
        return jsonify({"success": False, "message": "Scooter not found."}), 404

    if scooter.status == "in-use":
        return jsonify({"success": False, "message": "This scooter is already in use."}), 409

    if scooter.battery < 10:
        return jsonify({"success": False, "message": "This scooter has insufficient battery."}), 409

    booking = Booking(
        user_id=user.id,
        scooter_id=scooter.id,
        start_location=f"{scooter.latitude:.4f}, {scooter.longitude:.4f}",
        end_location=None,
        start_time=datetime.utcnow(),
        end_time=None,
        distance=0.0,
        cost=0.0,
        status="ongoing",
    )

    scooter.status = "in-use"

    db.session.add(booking)
    db.session.commit()

    return jsonify(
        {
            "success": True,
            "message": "Scooter unlocked successfully.",
            "booking": booking.to_dict(),
        }
    )


@booking_bp.post("/end")
def end_booking():
    user = get_current_user_from_token()
    if not user:
        return jsonify({"success": False, "message": "Unauthorized"}), 401

    booking = Booking.query.filter_by(user_id=user.id, status="ongoing").first()
    if not booking:
        return jsonify({"success": False, "message": "No ongoing trip found."}), 404

    scooter = booking.scooter
    if not scooter:
        return jsonify({"success": False, "message": "Associated scooter not found."}), 404

    booking.end_time = datetime.utcnow()
    booking.status = "completed"
    booking.end_location = f"{scooter.latitude:.4f}, {scooter.longitude:.4f}"

    duration_minutes = booking.get_duration_minutes()
    booking.distance = max(round(duration_minutes * 0.3, 1), 0.5)
    booking.cost = round(max(duration_minutes * (scooter.hourly_price / 60.0), 1.0), 2)

    scooter.status = "available"
    scooter.battery = max(scooter.battery - min(duration_minutes, 30), 5)

    db.session.commit()

    return jsonify(
        {
            "success": True,
            "message": "Trip ended successfully.",
            "booking": booking.to_dict(),
        }
    )