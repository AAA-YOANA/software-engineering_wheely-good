import re

from flask import Blueprint, current_app, jsonify, request
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

from extensions import db
from models import User

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")

EMAIL_REGEX = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def _make_token(user_id: int, email: str) -> str:
    serializer = URLSafeTimedSerializer(current_app.config["SECRET_KEY"])
    return serializer.dumps({"user_id": user_id, "email": email}, salt="auth-token")


def verify_token(token: str, max_age: int = 60 * 60 * 24 * 7):
    serializer = URLSafeTimedSerializer(current_app.config["SECRET_KEY"])
    try:
        data = serializer.loads(token, salt="auth-token", max_age=max_age)
        return data
    except (BadSignature, SignatureExpired):
        return None


def _validate_register_data(data: dict):
    full_name = (data.get("full_name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not full_name:
        return False, "Name is required.", None
    if len(full_name) > 100:
        return False, "Name must be 100 characters or fewer.", None
    if not email:
        return False, "Email is required.", None
    if not EMAIL_REGEX.match(email):
        return False, "Please enter a valid email address.", None
    if not password:
        return False, "Password is required.", None
    if len(password) < 6:
        return False, "Password must be at least 6 characters long.", None

    cleaned = {
        "full_name": full_name,
        "email": email,
        "password": password,
    }
    return True, None, cleaned


def _validate_login_data(data: dict):
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not email:
        return False, "Email is required.", None
    if not EMAIL_REGEX.match(email):
        return False, "Please enter a valid email address.", None
    if not password:
        return False, "Password is required.", None

    cleaned = {
        "email": email,
        "password": password,
    }
    return True, None, cleaned


@auth_bp.post("/register")
def register():
    data = request.get_json(silent=True) or {}
    is_valid, error_message, cleaned = _validate_register_data(data)

    if not is_valid:
        return jsonify({"success": False, "message": error_message}), 400

    existing_user = User.query.filter_by(email=cleaned["email"]).first()
    if existing_user:
        return jsonify({"success": False, "message": "This email is already registered."}), 409

    user = User(
        full_name=cleaned["full_name"],
        email=cleaned["email"],
        role="customer",
        is_active=True,
    )
    user.set_password(cleaned["password"])

    db.session.add(user)
    db.session.commit()

    return (
        jsonify(
            {
                "success": True,
                "message": "Registration successful. Please log in.",
                "user": user.to_dict(),
            }
        ),
        201,
    )


@auth_bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    is_valid, error_message, cleaned = _validate_login_data(data)

    if not is_valid:
        return jsonify({"success": False, "message": error_message}), 400

    user = User.query.filter_by(email=cleaned["email"]).first()
    if not user or not user.check_password(cleaned["password"]):
        return jsonify({"success": False, "message": "Invalid email or password."}), 401

    if not user.is_active:
        return jsonify({"success": False, "message": "This account has been disabled."}), 403

    token = _make_token(user.id, user.email)

    return jsonify(
        {
            "success": True,
            "message": "Login successful.",
            "token": token,
            "user": user.to_dict(),
        }
    )


@auth_bp.get("/me")
def get_current_user():
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return jsonify({"success": False, "message": "Missing token."}), 401

    token = auth_header.split(" ", 1)[1].strip()
    payload = verify_token(token)
    if not payload:
        return jsonify({"success": False, "message": "Invalid or expired token."}), 401

    user = User.query.get(payload["user_id"])
    if not user:
        return jsonify({"success": False, "message": "User not found."}), 404

    return jsonify({"success": True, "user": user.to_dict()})