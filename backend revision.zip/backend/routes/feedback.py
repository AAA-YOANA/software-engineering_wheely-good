from flask import Blueprint, request, jsonify
from models import Feedback, User
from extensions import db
from routes.auth import verify_token
import json

feedback_bp = Blueprint("feedback", __name__, url_prefix="/api/feedback")


def get_user():
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    data = verify_token(token)
    if not data:
        return None
    return User.query.get(data["user_id"])


# ======================
# 提交反馈
# ======================
@feedback_bp.post("")
def create_feedback():
    user = get_user()
    if not user:
        return jsonify({"success": False}), 401

    data = request.json

    feedback = Feedback(
        user_id=user.id,
        type=data.get("type"),
        type_label=data.get("typeLabel"),
        description=data.get("description"),
        images=json.dumps(data.get("images", [])),
        status="pending"
    )

    db.session.add(feedback)
    db.session.commit()

    return jsonify({"success": True})


# ======================
# 获取用户反馈
# ======================
@feedback_bp.get("/my")
def get_my_feedback():
    user = get_user()
    if not user:
        return jsonify({"success": False}), 401

    feedbacks = Feedback.query.filter_by(user_id=user.id).order_by(Feedback.id.desc()).all()

    return jsonify({
        "success": True,
        "data": [f.to_dict() for f in feedbacks]
    })