from datetime import datetime

from werkzeug.security import check_password_hash, generate_password_hash

from extensions import db


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)

    phone = db.Column(db.String(50), nullable=True)
    address = db.Column(db.String(255), nullable=True)
    avatar_url = db.Column(db.String(255), nullable=True)

    role = db.Column(db.String(20), nullable=False, default="customer")
    is_active = db.Column(db.Boolean, nullable=False, default=True)

    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    bookings = db.relationship("Booking", backref="user", lazy=True)
    payments = db.relationship("Payment", backref="user", lazy=True)

    def set_password(self, raw_password: str) -> None:
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password: str) -> bool:
        return check_password_hash(self.password_hash, raw_password)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "full_name": self.full_name,
            "email": self.email,
            "phone": self.phone,
            "address": self.address,
            "avatar_url": self.avatar_url,
            "role": self.role,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class Scooter(db.Model):
    __tablename__ = "scooters"

    id = db.Column(db.Integer, primary_key=True)
    scooter_code = db.Column(db.String(20), unique=True, nullable=False, index=True)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    battery = db.Column(db.Integer, nullable=False, default=100)
    status = db.Column(db.String(20), nullable=False, default="available")
    image_url = db.Column(db.String(500), nullable=True)
    hourly_price = db.Column(db.Float, nullable=False, default=5.0)

    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    bookings = db.relationship("Booking", backref="scooter", lazy=True)

    def to_dict(self) -> dict:
        return {
            "id": self.scooter_code,
            "position": [self.latitude, self.longitude],
            "battery": self.battery,
            "status": self.status,
            "image": self.image_url
            or "https://images.unsplash.com/photo-1583322319396-08178ea4f8b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
            "hourly_price": self.hourly_price,
        }


class Booking(db.Model):
    __tablename__ = "bookings"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    scooter_id = db.Column(db.Integer, db.ForeignKey("scooters.id"), nullable=False)

    start_location = db.Column(db.String(255), nullable=True)
    end_location = db.Column(db.String(255), nullable=True)

    start_time = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    end_time = db.Column(db.DateTime, nullable=True)

    distance = db.Column(db.Float, nullable=False, default=0.0)
    cost = db.Column(db.Float, nullable=False, default=0.0)

    status = db.Column(db.String(20), nullable=False, default="ongoing")

    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    def get_duration_minutes(self) -> int:
        if not self.end_time:
            delta = datetime.utcnow() - self.start_time
        else:
            delta = self.end_time - self.start_time
        return max(int(delta.total_seconds() // 60), 0)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "scooter_id": self.scooter.scooter_code if self.scooter else None,
            "date": self.start_time.strftime("%Y-%m-%d") if self.start_time else None,
            "time": self.start_time.strftime("%H:%M") if self.start_time else None,
            "duration": f"{self.get_duration_minutes()}分钟",
            "distance": f"{self.distance:.1f} km",
            "startLocation": self.start_location or "未知起点",
            "endLocation": self.end_location or "进行中",
            "cost": f"${self.cost:.2f}",
            "status": self.status,
            "battery": self.scooter.battery if self.scooter else None,
            "route": [],
            "scooterImage": self.scooter.image_url if self.scooter else None,
        }


class Payment(db.Model):
    __tablename__ = "payments"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    type = db.Column(db.String(20), nullable=False)
    last4 = db.Column(db.String(4), nullable=False)
    is_default = db.Column(db.Boolean, nullable=False, default=False)
    expiry_date = db.Column(db.String(10), nullable=True)
    holder_name = db.Column(db.String(100), nullable=True)

    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type,
            "last4": self.last4,
            "isDefault": self.is_default,
            "expiryDate": self.expiry_date,
            "holderName": self.holder_name,
        }
    
class Feedback(db.Model):
    __tablename__ = "feedbacks"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))

    type = db.Column(db.String(50))
    type_label = db.Column(db.String(50))

    description = db.Column(db.Text)

    images = db.Column(db.Text)  # JSON字符串存图片

    status = db.Column(db.String(20), default="pending")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    replies = db.relationship("FeedbackReply", backref="feedback", lazy=True)

    def to_dict(self):
        return {
            "id": self.id,
            "type": self.type,
            "typeLabel": self.type_label,
            "description": self.description,
            "images": eval(self.images) if self.images else [],
            "status": self.status,
            "createdAt": self.created_at.isoformat(),
            "replies": [r.to_dict() for r in self.replies]
        }


class FeedbackReply(db.Model):
    __tablename__ = "feedback_replies"

    id = db.Column(db.Integer, primary_key=True)
    feedback_id = db.Column(db.Integer, db.ForeignKey("feedbacks.id"))

    message = db.Column(db.Text)
    is_admin = db.Column(db.Boolean, default=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "message": self.message,
            "isAdmin": self.is_admin,
            "createdAt": self.created_at.isoformat()
        }