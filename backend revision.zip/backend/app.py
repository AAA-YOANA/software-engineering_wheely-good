from flask import Flask, jsonify

from config import Config
from extensions import cors, db
from routes.auth import auth_bp
from routes.booking import booking_bp
from routes.payment import payment_bp
from routes.scooter import scooter_bp
from routes.user import user_bp
from routes.feedback import feedback_bp


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    cors.init_app(
        app,
        resources={r"/api/*": {"origins": "*"}},
        supports_credentials=False,
    )

    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(payment_bp)
    app.register_blueprint(scooter_bp)
    app.register_blueprint(booking_bp)
    app.register_blueprint(feedback_bp)

    @app.get("/")
    def home():
        return jsonify({"success": True, "message": "WheelyGood backend is running."})

    @app.get("/api/health")
    def health_check():
        return jsonify({"success": True, "message": "API is healthy."})

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)