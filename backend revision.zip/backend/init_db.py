from app import app
from extensions import db
from models import Payment, Scooter, User


def seed_users():
    if User.query.count() == 0:
        user = User(
            full_name="Test User",
            email="test@example.com",
            phone="13800138000",
            address="Leeds City Centre",
            avatar_url="https://i.pravatar.cc/150?img=12",
            role="customer",
            is_active=True,
        )
        user.set_password("123456")
        db.session.add(user)
        db.session.commit()

        payment1 = Payment(
            user_id=user.id,
            type="visa",
            last4="4532",
            is_default=True,
            expiry_date="12/26",
            holder_name="Test User",
        )
        payment2 = Payment(
            user_id=user.id,
            type="alipay",
            last4="8888",
            is_default=False,
            holder_name="Test User",
        )
        db.session.add(payment1)
        db.session.add(payment2)
        db.session.commit()


def seed_scooters():
    if Scooter.query.count() == 0:
        scooters = [
            Scooter(
                scooter_code="SC-001",
                latitude=39.9042,
                longitude=116.4074,
                battery=85,
                status="available",
                image_url="https://images.unsplash.com/photo-1583322319396-08178ea4f8b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
                hourly_price=6.0,
            ),
            Scooter(
                scooter_code="SC-002",
                latitude=39.9142,
                longitude=116.4174,
                battery=25,
                status="low-battery",
                image_url="https://images.unsplash.com/photo-1742078684146-43ad5c9a7388?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
                hourly_price=6.0,
            ),
            Scooter(
                scooter_code="SC-003",
                latitude=39.9092,
                longitude=116.4124,
                battery=60,
                status="in-use",
                image_url="https://images.unsplash.com/photo-1764003000916-b002dbcab88b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
                hourly_price=6.0,
            ),
            Scooter(
                scooter_code="SC-004",
                latitude=39.9002,
                longitude=116.4024,
                battery=95,
                status="available",
                image_url="https://images.unsplash.com/photo-1629099580192-b8300533fc06?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
                hourly_price=6.0,
            ),
            Scooter(
                scooter_code="SC-005",
                latitude=39.9082,
                longitude=116.4154,
                battery=72,
                status="available",
                image_url="https://images.unsplash.com/photo-1583322319396-08178ea4f8b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
                hourly_price=6.0,
            ),
        ]
        db.session.add_all(scooters)
        db.session.commit()


def init_database():
    with app.app_context():
        db.create_all()
        seed_users()
        seed_scooters()
        print("Database tables created and seed data inserted successfully.")


if __name__ == "__main__":
    init_database()